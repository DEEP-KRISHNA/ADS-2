import java.util.Arrays;
import edu.princeton.cs.algs4.HexDump;
import edu.princeton.cs.algs4.BinaryStdIn;
import edu.princeton.cs.algs4.BinaryStdOut;
import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;

public class BurrowsWheeler {

    // apply Burrows-Wheeler transform,
    // reading from standard input and writing to standard output
    public static void transform() {
        String inpt = BinaryStdIn.readString();
        CircularSuffixArray suff = new CircularSuffixArray(inpt);
        for (int i = 0; i < inpt.length(); i++) {
            if (suff.index(i) == 0) {
                BinaryStdOut.write(i);
                break;
            }
        }
        for (int i = 0; i < inpt.length(); i++) {
            if (suff.index(i) == 0) {
                BinaryStdOut.write(inpt.charAt(inpt.length() - 1));
            } else {
                BinaryStdOut.write(inpt.charAt(suff.index(i) - 1));
            }

        }
        BinaryStdOut.flush();
        BinaryStdOut.close();
        BinaryStdIn.close();
    }

    // apply Burrows-Wheeler inverse transform,
    // reading from standard input and writing to standard output
    public static void inverseTransform() {
        String inputstr = BinaryStdIn.readString();
        String postemp = inputstr.split("\n")[0].trim();

        char post_char[] = postemp.toCharArray();
        char str_char[] = postemp.toCharArray();

        Arrays.sort(post_char);

        String str1 = new String(str_char);
        String str2 = new String(post_char);
        int[] next = new int[str_char.length];
        for (int i = 0; i < str1.length(); i++) {
            next[i] = str1.indexOf(str2.charAt(i));
            if (next[i] == str1.length() - 1) {
                str1 = str1.substring(0, next[i]) + ("" + ((char) 231));
            } else {
                str1 = str1.substring(0, next[i]) + ("" + ((char) 231)) + str1.substring(next[i] + 1);
            }
            // str1 = str1.replaceFirst(("" + str2.charAt(i)), ("" + ((char) 231)));
        }

        int finalpos = str1.length();
        while (finalpos != 0) {
            if (finalpos == str1.length()) {
                finalpos = 0;
            }
            BinaryStdOut.write(post_char[next[finalpos]]);
            finalpos = next[finalpos];
        }
        BinaryStdOut.flush();
        BinaryStdOut.close();
        BinaryStdIn.close();

        // System.out.println(actualpos);
    }

    // if args[0] is "-", apply Burrows-Wheeler transform
    // if args[0] is "+", apply Burrows-Wheeler inverse transform
    public static void main(String[] args) {
        if (args[0].equals("-")) {
            transform();
        } else if (args[0].equals("+")) {
            inverseTransform();
        }
    }

}